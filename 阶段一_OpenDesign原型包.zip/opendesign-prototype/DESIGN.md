# 知境 · 设计交接

## 目标与范围

阶段一单角色沉浸式探究：教师设计并确认角色，学生对话、核验资料、形成个人判断，教师回看过程。

不加入多角色切换、圆桌、代写最终结论或独立治理平台。

## 视觉规则

- 安静的教学工作台；低饱和绿色与纸白，赭色表示待确认或证据不足。
- 主色 #245a48；页面背景 #f7f8f4；边线 #e2e7dc。
- 系统无衬线字体；场景标题和人物名使用系统宋体回退。
- 主体圆角 14px，按钮 8px，标签 5px。
- 桌面导航 218px，内容最大宽 1440px；内容边距 38px，栅格间距 18～23px。
- 900px 以下折叠导航；620px 以下表单及多列内容改为单列。
- 图标为内置矢量，无在线字体、图片或脚本依赖。

优先通过 CSS 变量和公共组件修改，避免逐页产生不一致的样式。

## 页面映射

| 页面 | URL 片段 | 后续组件 |
| --- | --- | --- |
| 任务列表 | #tasks | AppShell、TaskCard、TaskFilter |
| 教师设计 | #editor | TaskBriefForm、SourceList、RoleCardForm、TaskSettings |
| 预览发布 | #preview | PreviewChecklist、PreviewConversation、PublishConfirmation |
| 学生探究 | #chat | RolePanel、Conversation、SourceDrawer、NotesPanel、RunStatus |
| 最终成果 | #submission | SubmissionForm、EvidenceSelector、SubmitConfirmation |
| 教学报告 | #report | StudentTable、TraceDialog、RiskList、ManualReview |
| 演示身份 | 点击头像 | 正式版改为 LoginPage |

## 必须保留的交互

- 修改时间、目标、资料或角色后，核验和预览结果失效。
- 覆盖人工编辑、发布、替换演示会话和提交成果需要明确确认。
- 发布条件包含角色检查、五类预览通过、当前版本人工确认。
- 草稿与会话快照独立，旧会话不自动更新。
- 资料不足不创建引用，冲突材料并列展示。
- 来源包含文件与位置，抽屉保留上下文。
- 笔记保留原始回答、学生判断、可信程度与局限。
- 没有“一键生成最终结论”。
- 成果提交后冻结。
- 风险记录定位具体回答；成功拦截不算角色违规。
- 输入内容作为文本显示，不作为脚本执行。

## 给 OpenDesign 的修改约束

> 在当前 index.html 上修改视觉设计，保留单角色阶段一范围。保留所有 data-route、data-model、data-action、data-source、data-submission 等交互属性和元素 id。保持页面切换、来源抽屉、笔记、五类审核、人工确认和成果提交可用。不得加入多角色切换、代写结论，不得移除来源与认知边界提示。完成后在 Preview 检查交互，不要只交付截图。

## 给前端开发者的交接约束

> 以最终确认 HTML 为视觉母版，迁移到 React + TypeScript，复用相同颜色、字号、间距及响应式规则。接入已有接口文档，不把浏览器状态当作权限与版本真相。在同一窗口尺寸检查普通态、来源抽屉、失败重试、发布确认与提交后只读状态。固定演示回答不代表真实模型验收通过。

## 动态内容编辑

角色名、任务标题等会由脚本绑定值更新。OpenDesign 中直接修改可见文字可能被运行状态覆盖。

- 静态文案和样式可用可视化编辑。
- 默认业务数据在 Code 中编辑对应 data-model 表单默认值。
- 改默认值后，通过“演示状态”重置之前保存的 localStorage。
- 导出后将导出 HTML 作为新的母版，不用旧 src 覆盖。

